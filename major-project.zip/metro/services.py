from collections import defaultdict
import heapq
from .models import Station, Connection

class PathSegment:
    def __init__(self, station, time, distance):
        self.station = station
        self.time = time
        self.distance = distance

class MetroService:
    def __init__(self):
        self._initialize_graph()

    def _initialize_graph(self):
        self.metro_map = defaultdict(list)
        self.stations = {station.name: station for station in Station.objects.all()}
        
        connections = Connection.objects.select_related('from_station', 'to_station').all()
        for conn in connections:
            self.metro_map[conn.from_station.name].append(
                PathSegment(conn.to_station.name, conn.time, conn.distance)
            )
            self.metro_map[conn.to_station.name].append(
                PathSegment(conn.from_station.name, conn.time, conn.distance)
            )

    def find_path(self, source, destination, mode='time'):
        if source not in self.stations or destination not in self.stations:
            return None, "Invalid station names."

        distances, paths = self._dijkstra(source, destination, mode)
        
        if destination not in distances:
            return None, "No path found."

        path = self._reconstruct_path(paths, source, destination)
        journey_details = self._get_journey_details(path, mode)
        
        return journey_details, None

    def _dijkstra(self, source, destination, mode):
        distances = {source: 0}
        paths = {source: None}
        queue = [(0, source)]
        
        while queue:
            current_cost, current_station = heapq.heappop(queue)
            
            if current_station == destination:
                break
                
            if current_cost > distances[current_station]:
                continue
                
            for segment in self.metro_map[current_station]:
                cost = current_cost + getattr(segment, mode)
                
                if segment.station not in distances or cost < distances[segment.station]:
                    distances[segment.station] = cost
                    paths[segment.station] = current_station
                    heapq.heappush(queue, (cost, segment.station))
        
        return distances, paths

    def _reconstruct_path(self, paths, source, destination):
        path = []
        current = destination
        
        while current is not None:
            path.append(current)
            current = paths.get(current)
            
        return list(reversed(path))

    def _get_journey_details(self, path, mode):
        journey_details = []
        total_distance = 0
        total_time = 0
        
        for i in range(len(path) - 1):
            from_station = path[i]
            to_station = path[i + 1]
            
            segment = next(
                seg for seg in self.metro_map[from_station] 
                if seg.station == to_station
            )
            
            journey_details.append({
                'from': from_station,
                'to': to_station,
                'distance': segment.distance,
                'time': segment.time,
                'from_line': self.stations[from_station].line_color,
                'to_line': self.stations[to_station].line_color,
                'is_interchange': (
                    self.stations[from_station].line_color != 
                    self.stations[to_station].line_color
                )
            })
            
            total_distance += segment.distance
            total_time += segment.time
        
        return {
            'journey_details': journey_details,
            'total_distance': total_distance,
            'total_time': total_time,
            'path': path,
            'num_interchanges': sum(
                1 for detail in journey_details if detail['is_interchange']
            )
        }
